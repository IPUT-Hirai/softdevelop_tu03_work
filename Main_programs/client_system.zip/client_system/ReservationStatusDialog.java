// @4 予約状況確認機能で新たに追加したクラス
package client_system;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Choice;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.ArrayList;
import java.util.List;

public class ReservationStatusDialog extends Dialog implements ActionListener, WindowListener, ItemListener{
	ReservationControl	rc;											// ReservationControlクラスのインスタンス保存
	
	// ========== 修正：日付選択をChoiceコンポーネントに変更 ==========
	ChoiceFacility	choiceFacility;									// 教室選択用コンボボックス
	Choice			choiceYear, choiceMonth, choiceDay;				// 年月日のChoiceコンポーネント
	Button			buttonSearch;									// 検索ボタン
	// =========================================================
	
	TextArea	textReservations;									// 予約状況表示用テキストエリア
	Button		buttonClose;										// 閉じるボタン
	
	Panel		panelNorth;											// 上部パネル（検索条件入力用）
	Panel		panelCenter;										// 中央パネル
	Panel		panelSouth;											// 下部パネル
	
	public	ReservationStatusDialog( Frame arg0, ReservationControl rc) {
		super( arg0, "予約状況確認", true);							// Superクラスのコンストラクタ呼出
		this.rc = rc;												// ReservationControlインスタンス保存
		
		// ========== 修正：日付選択用Choiceコンポーネントの生成 ==========
		// 教室選択用コンボボックスの生成
		List<String> facilityId = new ArrayList<String>();			// 全てのfacilityIDを入れるリスト
		facilityId = rc.getFacilityId();							// 全facilityIDを読出し，リストに入れる
		choiceFacility = new ChoiceFacility( facilityId);			// 教室選択用コンボボックスのインスタンス生成
		
		// 年のChoiceコンポーネント生成（2024〜2027年）
		choiceYear = new Choice();
		for(int year = 2024; year <= 2027; year++) {
			choiceYear.add(String.valueOf(year));
		}
		choiceYear.select("2025");									// デフォルトで2025年を選択
		
		// 月のChoiceコンポーネント生成（1〜12月）
		choiceMonth = new Choice();
		for(int month = 1; month <= 12; month++) {
			choiceMonth.add(String.valueOf(month));
		}
		choiceMonth.select("1");									// デフォルトで1月を選択
		
		// 日のChoiceコンポーネント生成（1〜31日）
		choiceDay = new Choice();
		updateDayChoice();											// 月に応じた日数を設定
		
		// 検索ボタンの生成
		buttonSearch = new Button("予約確認");
		// ========================================================
		
		// テキストエリアの生成
		textReservations = new TextArea( 15, 100);					// 予約状況表示用テキストエリア生成
		textReservations.setEditable( false);						// テキストエリアをユーザによる編集不可に設定
		
		// ボタンの生成
		buttonClose	= new Button( "閉じる");						// 閉じるボタン生成
		
		// パネルの生成
		panelNorth = new Panel();									// 上部パネル生成
		panelCenter	= new Panel();									// 中央パネル生成
		panelSouth	= new Panel();									// 下部パネル生成
		
		// ========== 修正：上部パネルにChoiceコンポーネントを配置 ==========
		// 上部パネルに検索条件入力欄を配置
		panelNorth.add( new Label("教室　"));
		panelNorth.add( choiceFacility);
		panelNorth.add( new Label("　日付"));
		panelNorth.add( choiceYear);
		panelNorth.add( new Label("年"));
		panelNorth.add( choiceMonth);
		panelNorth.add( new Label("月"));
		panelNorth.add( choiceDay);
		panelNorth.add( new Label("日"));
		panelNorth.add( new Label("　"));
		panelNorth.add( buttonSearch);
		// ===========================================================
		
		// 中央パネルに予約状況表示テキストエリアを追加
		panelCenter.add( textReservations);
		
		// 下部パネルに閉じるボタンを追加
		panelSouth.add( buttonClose);								// 閉じるボタン追加
		
		// ReservationStatusDialogをBorderLayoutに設定し，3つのパネルを追加
		setLayout( new BorderLayout());
		add( panelNorth, BorderLayout.NORTH);
		add( panelCenter, BorderLayout.CENTER);
		add( panelSouth, BorderLayout.SOUTH);
		
		textReservations.setText( "           教室と日付を選択して予約確認ボタンを押してください。");
		
		// Window Listenerを追加
		addWindowListener( this);
		
		// ========== 修正：ItemListenerも追加 ==========
		// ボタンにAction Listenerを追加
		buttonClose.addActionListener( this);
		buttonSearch.addActionListener( this);
		
		// 月の選択が変更されたら日の選択肢を更新するためのItemListener
		choiceMonth.addItemListener( this);
		choiceYear.addItemListener( this);
		// ==========================================
	}

	// ========== 追加：月に応じて日の選択肢を更新するメソッド ==========
	private void updateDayChoice() {
		String currentDay = choiceDay.getSelectedItem();			// 現在選択されている日を保存
		choiceDay.removeAll();										// 日の選択肢をクリア
		
		int year = Integer.parseInt(choiceYear.getSelectedItem());
		int month = Integer.parseInt(choiceMonth.getSelectedItem());
		int maxDay = getMaxDayOfMonth(year, month);					// その月の最大日数を取得
		
		for(int day = 1; day <= maxDay; day++) {
			choiceDay.add(String.valueOf(day));
		}
		
		// 以前選択されていた日が有効なら復元、無効なら1日を選択
		if(currentDay != null && Integer.parseInt(currentDay) <= maxDay) {
			choiceDay.select(currentDay);
		} else {
			choiceDay.select("1");
		}
	}
	
	// 指定された年月の最大日数を返すメソッド
	private int getMaxDayOfMonth(int year, int month) {
		switch(month) {
			case 2:														// 2月
				return (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)) ? 29 : 28;	// うるう年判定
			case 4: case 6: case 9: case 11:							// 4, 6, 9, 11月
				return 30;
			default:													// その他の月
				return 31;
		}
	}
	// =============================================================

	@Override
	public void itemStateChanged(ItemEvent e) {
		// ========== 追加：年月の選択が変更されたら日の選択肢を更新 ==========
		if(e.getSource() == choiceMonth || e.getSource() == choiceYear) {
			updateDayChoice();
		}
		// =============================================================
	}

	@Override
	public void windowOpened(WindowEvent e) {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	@Override
	public void windowClosing(WindowEvent e) {
		setVisible( false);											// ダイアログを非表示化
		dispose();													// ダイアログの部品を破棄
		
	}

	@Override
	public void windowClosed(WindowEvent e) {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	@Override
	public void windowActivated(WindowEvent e) {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if( e.getSource() == buttonClose) {							// 閉じるボタン押下時
			setVisible( false);										// ダイアログ非表示
			dispose();												// ダイアログの部品を破棄
			
		// ========== 修正：Choiceコンポーネントから値を取得 ==========
		} else if( e.getSource() == buttonSearch) {				// 検索ボタン押下時
			String facility = choiceFacility.getSelectedItem();	// 選択された教室IDを取得
			String year = choiceYear.getSelectedItem();			// 選択された年を取得
			String month = choiceMonth.getSelectedItem();			// 選択された月を取得
			String day = choiceDay.getSelectedItem();				// 選択された日を取得
			
			// 検索実行して結果を表示
			String result = rc.getReservationsByFacilityAndDate(facility, year, month, day);
			textReservations.setText(result);
		// ========================================================
		}
	}
}